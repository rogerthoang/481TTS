from Heuristic.heuristicX import *
from Heuristic.heuristicY import *

def print_pos(pos):
    print()
    uni_pieces = {'R':'♜', 'N':'♞', 'B':'♝', 'Q':'♛', 'K':'♚', 'P':'♟',
                  'r':'♖', 'n':'♘', 'b':'♗', 'q':'♕', 'k':'♔', 'p':'♙', '.':'·'}
    for i, row in enumerate(pos.board.split()):
        print(' ', 8-i, ' '.join(uni_pieces.get(p, p) for p in row))
    print('    a b c d e f g h \n\n')
	
def is_checkmate(position, MATE_LOWER):
	if position.score <= -MATE_LOWER:
		return True
	else:
		return False

def evaluate(position, player):
	if player:	
		return heuristicX(position)
	else:
		return heuristicY(position)


def minimax(position, depth, player, MATE_LOWER):
	"""Returns a tuple (score, bestmove) for the position at the given depth"""
	if depth == 0 or is_checkmate(position, MATE_LOWER): #or position.is_draw():
		return (evaluate(position, player), position)
		
	else: 
		if player:
			bestscore = -float("inf")
			bestmove = None
			for move in position.gen_moves():
				#print(type(move))
				#print(move)
				new_position = position.move(move)
				#print("New Position: {}".format(new_position))
				#print_pos(new_position)
				score, move = minimax(new_position, depth - 1, player, MATE_LOWER)

				if score > bestscore: # white maximizes her score
					bestscore = score
					bestmove = move
			#print(bestscore, bestmove)
			return (bestscore, bestmove)
		else:
			bestscore = float("inf")
			bestmove = None
			for move in position.gen_moves():
				new_position = position.move(move)
				score, move = minimax(new_position, depth - 1, player, MATE_LOWER)
				if score < bestscore: # black minimizes his score
					bestscore = score
					bestmove = move
			return (bestscore, bestmove)