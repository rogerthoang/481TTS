def heuristicX(position):
	#print(position.score)
	return position.score