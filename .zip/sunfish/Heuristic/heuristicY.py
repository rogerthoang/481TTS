def heuristicY(position):
	return position.score