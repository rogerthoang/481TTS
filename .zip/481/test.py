import chess
from IPython.display import SVG, display


def main():
	board = chess.Board()
	print(board)

if __name__ == "__main__":
	main()